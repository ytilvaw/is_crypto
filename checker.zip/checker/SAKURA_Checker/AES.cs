﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Security.Cryptography;

namespace SAKURA
{
    class AES
    {
        private AesCryptoServiceProvider aes;
        private ICryptoTransform enc;
        private ICryptoTransform dec;

        public AES()
        {
            aes = new AesCryptoServiceProvider();
            aes.BlockSize = 128;
            aes.FeedbackSize = 128;
            aes.KeySize = 128;
            aes.Mode = CipherMode.ECB;
            aes.Padding = PaddingMode.None;
            aes.IV = new byte[] { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 };
        }

        public void SetKey(byte[] key)
        {
            aes.Key = key;
            enc = aes.CreateEncryptor(aes.Key, aes.IV);
            dec = aes.CreateDecryptor(aes.Key, aes.IV);
        }

        public void Encrypt(ref byte[] ciphertext, byte[] key, byte[] plaintext)
        {
            //ciphertext = enc.TransformFinalBlock(plaintext, 0, plaintext.Length);
            int i,j;
	
            uint[] mul_res = new uint[256];
            
            uint[] c1 = new uint[256];
            uint[] c2 = new uint[256];
            uint[] r2 = new uint[256];

            for (i =0; i<256; i++){
                c2[i]=plaintext[511-i];
                c1[i]=plaintext[255-i];        
            }

            for (i = 0; i < 32; i++)
            {
                for (j = 0; j < 8; j++)
                {
                    r2[(i * 8) + j] = Convert.ToByte((key[31-i] & (1 << j))>>j);
                }
            }
        	
            //Convert key to binary poly

            //Compute c1.r2; mul_res=c1rot*r2;
            for (i=0; i<256; i++){//loop over p2
                if (r2[i] == 1)
                {
                    for (j=0; j<256; j++)//add 256 intermediate values
                        if (j+i>255)
                            mul_res[j+i-256] = (mul_res[j+i-256] + (256-c1[j]))&0xFF;
                        else    
                            mul_res[j+i]=(mul_res[j+i]+c1[j])&0xFF;
                }
            }

            //Convert c2 512 degree to 256 degree
	        for(i = 0; i< 256; i++){
		        c2[i] = (c2[i] + mul_res[i])&0xFF;
	        }

            byte[] temp = new byte[32];

            for(i=0; i<256; i++){
            // Decode(m) = 1 if m between q/4,-q/4, 0 else
                if ((c2[i] < 256 >> 2) || (c2[i] >= 3 * 256 >> 2))
                {
                    temp[31-(i >> 3)] = Convert.ToByte(temp[31 - (i >> 3)] | (0 << (i % 8)));
                }
                else{
                    temp[31-(i >> 3)] = Convert.ToByte(temp[31 - (i >> 3)] | (1 << (i % 8)));
                }
            }
            ciphertext = temp;             
        }

        public void Decrypt(byte[] plaintext, byte[] ciphertext)
        {
            plaintext = dec.TransformFinalBlock(ciphertext, 0, ciphertext.Length);
        }
    }
}
