﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;
using System.IO;
using System.Text;

namespace SAKURA
{
    class Controller
    {
        private BackgroundWorker worker;
        private CipherModule targetModule;
        private AES pcModule;

        public Controller()
        {
            worker = new BackgroundWorker();
            worker.WorkerReportsProgress = true;
            worker.WorkerSupportsCancellation = true;
            worker.DoWork += new DoWorkEventHandler(worker_DoWork);
            pcModule = new AES();
        }

        public void Open(uint index)
        {
            targetModule = new CipherModule(index);
        }

        public void Close()
        {
            targetModule.Dispose();
        }

        public void AddCompletedEventHandler(RunWorkerCompletedEventHandler handler)
        {
            worker.RunWorkerCompleted += handler;
        }

        public void AddProgressChangedEventHandler(ProgressChangedEventHandler handler)
        {
            worker.ProgressChanged += handler;
        }

        public void Run(ControllerArgs args)
        {
            worker.RunWorkerAsync((object)args);
        }

        public void Cancel()
        {
            worker.CancelAsync();
        }

        private void worker_DoWork(object sender, DoWorkEventArgs e)
        {
            ControllerArgs args = (ControllerArgs)e.Argument;
            ControllerArgs res = args.Clone();
            int progress = 0;

            e.Cancel = false;

            


            // initialize
            res.last = false;
            res.error = false;
            res.current_trace = 0;
            pcModule.SetKey(res.key);
            targetModule.Reset();
            targetModule.SetModeEncrypt(true);
            targetModule.SetKey(res.key);
            worker.ReportProgress(0, (object)res);

            ControllerArgs.textnum = ControllerArgs.textnum + 1;

            using (StreamWriter writer = File.AppendText("test_vectors.txt"))
            //string filename = ControllerArgs.textnum.ToString() + ".txt";
            //using (StreamWriter writer = new StreamWriter(filename))
            {
                while (res.endless || res.current_trace < res.traces)
                {
                    string tempFile1 = @"C:\Program Files\Pico Technology\SDK\src\MATLAB\ps2000\temp1.txt";
                    string tempFile2 = @"C:\Program Files\Pico Technology\SDK\src\MATLAB\ps2000\temp2.txt";
                    //while (!File.Exists(tempFile1))
                    //{
                        //while (!File.Exists(tempFile2))
                        //{
                        //    File.Delete(tempFile1);    
                        //}
                    //}
                    //File.Delete(tempFile1);
                    //using (File.Create(tempFile1))
                    //{
                    //}

                    //File.Delete(tempFile1);                    
                    //File.Delete(tempFile2);
                    res.answer = null;
                    res.ciphertext = null;
                    res.difference = null;
                    res.current_trace++;

                    if (!res.endless)
                    {
                        progress = (int)(100 * res.current_trace / res.traces);
                    }

                    if (res.randomGeneration)
                    {
                        res.plaintext = res.rand.generatePlaintext();
                    }

                    pcModule.Encrypt(ref res.answer, res.key, res.plaintext);
                    worker.ReportProgress(progress, (object)res);

                    int print_text;

                    for (print_text = 0; print_text < 32; print_text++)
                    {
                        writer.Write(res.key[print_text].ToString("X2"));
                    } writer.Write("\n");
                    writer.Flush();

                    for (print_text = 0; print_text < 256; print_text++)
                    {
                        writer.Write(res.plaintext[print_text].ToString("X2"));
                    } writer.Write("\n");
                    writer.Flush();

                    for (print_text = 256; print_text < 512; print_text++)
                    {
                        writer.Write(res.plaintext[print_text].ToString("X2"));
                    } writer.Write("\n");
                    writer.Flush();

                    for (print_text = 0; print_text < 32; print_text++)
                    {
                        writer.Write(res.answer[print_text].ToString("X2"));
                    } writer.Write("\n");
                    writer.Flush();

                    /*
                    for (print_text = 0; print_text < 512; print_text++)
                    {
                        writer.Write(res.plaintext[print_text] + ",");
                    }
                    writer.Flush();
                    */


                    targetModule.Run(ref res.ciphertext, res.plaintext, res.wait, ref res.elapsed);
                    res.diff = Utils.differenceByteArray(ref res.difference, res.answer, res.ciphertext);

                    /*
                    for (print_text = 0; print_text < 16; print_text++)
                    {
                        writer.Write(res.ciphertext[print_text] + ",");
                    }
                    */
                    writer.Write("\n");


                    //while (!File.Exists(tempFile1))
                    //{
                    //    System.Threading.Thread.Sleep(10);
                    //}
                    System.Threading.Thread.Sleep(10);
                    //File.Delete(tempFile1);

                    worker.ReportProgress(progress, (object)res);

                    if (res.diff)
                    {
                        res.error = true;
                        if (!res.continueIfError)
                        {
                            break;
                        }
                    }

                    if (worker.CancellationPending)
                    {
                        e.Cancel = true;
                        break;
                    }

                    if (res.single)
                    {
                        progress = 100;
                        break;
                    }
                }
            }
            res.last = true;
            worker.ReportProgress(progress, (object)res);
            e.Result = (object)res;
        }
    }

    public struct ControllerArgs
    {
        public bool single;
        public long traces;
        public bool endless;
        public long current_trace;
        public byte[] key;
        public byte[] plaintext;
        public bool randomGeneration;
        public int wait;
        public byte[] ciphertext;
        public byte[] answer;
        public byte[] difference;
        public bool diff;
        public bool continueIfError;
        public bool error;
        public double elapsed;
        public RandGen rand;
        public bool last;
        public static int textnum;

        public ControllerArgs Clone()
        {
            return (ControllerArgs)MemberwiseClone();
        }
    }
}
